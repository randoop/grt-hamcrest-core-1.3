package org.hamcrest.core;

public class SampleSubClass extends SampleBaseClass {
    
    public SampleSubClass(String value) {
        super(value);
    }

}
